package qn3;

public interface Resistive {

     double getResistivity();

}
