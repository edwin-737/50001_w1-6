package qn3;

public interface Conductive {
    double getConductivity();

}
